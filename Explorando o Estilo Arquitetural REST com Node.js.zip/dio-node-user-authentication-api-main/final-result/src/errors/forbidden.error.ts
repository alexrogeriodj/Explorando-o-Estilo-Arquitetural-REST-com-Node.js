
import { ApplicationError } from './application.error';

export class ForbiddenError extends ApplicationError<void> { };

